package main

// ============================================================
// Lab 02 — Chord DHT
// File: ring.go
// Role: Ring operations — lookup, join, maintenance
//
// TASKS IN THIS FILE:
//   Task 3 — findSuccessor()
//   Task 4 — closestPrecedingFinger()
//   Task 5 — join()
//   Task 6 — stabilize()
//   Task 7 — fixFingers()
// ============================================================

import (
	"fmt"
	"log"
	"time"
)

// ============================================================
// TASK 3 — findSuccessor
// ============================================================
// Find which node is responsible for the given id.
// This is the core Chord lookup algorithm.
//
// Algorithm:
//   1. Check if id falls in (n.info.ID, n.successor().ID]
//      → If yes: our successor owns it, return successor
//   2. Otherwise: forward to the closest preceding finger
//      → Call FindSuccessor RPC on that finger node
//      → Return its answer
//
// Special case: if closestPrecedingFinger returns this node itself,
// return this node (avoids infinite loop)
//
// HINT: use inRange(id, n.info.ID, n.successor().ID)
//       use closestPrecedingFinger(id)
//       use callRPC(addr, "ChordRPC.FindSuccessor", args, reply)
//
// TODO: implement this function
func (n *Node) findSuccessor(id uint8) (NodeInfo, error) {
	// YOUR CODE HERE
	return n.info, nil
}

// ============================================================
// TASK 4 — closestPrecedingFinger
// ============================================================
// Search the finger table for the closest node preceding id.
//
// Algorithm:
//   Walk fingers from M-1 DOWN to 0.
//   Return the first finger whose ID falls in (n.info.ID, id).
//   If no finger qualifies, return this node itself.
//
// HINT: use inRange(finger.ID, n.info.ID, id)
//       remember to acquire read lock: n.mu.RLock() / n.mu.RUnlock()
//
// TODO: implement this function
func (n *Node) closestPrecedingFinger(id uint8) NodeInfo {
	// YOUR CODE HERE
	return n.info
}

// ============================================================
// TASK 5 — join
// ============================================================
// Join the Chord ring.
//
// Case A — existingAddr is empty: CREATE a new ring
//   → Set predecessor to nil
//   → Set all fingers to point to self (already done by newNode)
//   → Done — this node is alone on the ring
//
// Case B — existingAddr is provided: JOIN an existing ring
//   → Call FindSuccessor RPC on existingAddr to find OUR successor
//      (pass n.info.ID as the ID to look up)
//   → Set fingers[0] to the returned successor
//   → Set predecessor to nil (stabilize will discover it later)
//
// HINT: use callRPC(existingAddr, "ChordRPC.FindSuccessor", args, reply)
//       use FindSuccessorArgs{ID: n.info.ID} as the args
//       use n.mu.Lock() / n.mu.Unlock() when updating fingers
//
// TODO: implement this function
func (n *Node) join(existingAddr string) error {
	if existingAddr == "" {
		// Case A: create new ring
		// YOUR CODE HERE
		return nil
	}
	// Case B: join existing ring
	// YOUR CODE HERE
	return nil
}

// ============================================================
// TASK 6 — stabilize
// ============================================================
// Periodically called to keep successor pointers correct.
//
// Algorithm:
//   1. Ask our successor for its predecessor
//      → Call GetPredecessor RPC on successor
//   2. If that predecessor (call it x) exists AND
//      x.ID falls in (n.info.ID, n.successor().ID)
//      → x is a better successor for us — update fingers[0] = x
//   3. Notify our (possibly updated) successor that we exist
//      → Call Notify RPC on successor with our NodeInfo
//
// If any RPC fails, just return (network issues are temporary)
//
// HINT: use GetPredecessorArgs{} and GetPredecessorReply{}
//       use NotifyArgs{Node: n.info} and NotifyReply{}
//
// TODO: implement this function
func (n *Node) stabilize() {
	// YOUR CODE HERE
}

// ============================================================
// TASK 7 — fixFingers
// ============================================================
// Periodically called to refresh one finger table entry.
// Rotates through fingers one at a time using n.next.
//
// Algorithm:
//   1. Read n.next (the current finger index to fix)
//   2. Calculate: start = (n.info.ID + 2^next) mod RING_SIZE
//   3. Call findSuccessor(start) to get the correct node for that finger
//   4. Update fingers[next] with the result
//   5. Increment n.next, wrap to 0 after reaching M
//
// HINT: 2^i in Go: uint8(1) << uint(i)
//       wrap: n.next = (n.next + 1) % M
//       use n.mu.Lock() when reading/writing n.next and n.fingers
//
// TODO: implement this function
func (n *Node) fixFingers() {
	// YOUR CODE HERE
}

// ============================================================
// Below this line — already implemented, do not change
// ============================================================

// checkPredecessor verifies our predecessor is still alive.
func (n *Node) checkPredecessor() {
	n.mu.RLock()
	pred := n.predecessor
	n.mu.RUnlock()

	if pred == nil {
		return
	}
	err := callRPC(pred.Addr, "ChordRPC.Ping", &PingArgs{}, &PingReply{})
	if err != nil {
		log.Printf("[RING] Predecessor ID:%d appears to have failed — clearing", pred.ID)
		n.mu.Lock()
		n.predecessor = nil
		n.mu.Unlock()
	}
}

// startBackgroundTasks launches periodic maintenance goroutines.
func (n *Node) startBackgroundTasks() {
	go func() {
		for {
			time.Sleep(500 * time.Millisecond)
			n.stabilize()
		}
	}()
	go func() {
		for {
			time.Sleep(500 * time.Millisecond)
			n.fixFingers()
		}
	}()
	go func() {
		for {
			time.Sleep(1 * time.Second)
			n.checkPredecessor()
		}
	}()
	fmt.Println("[RING] Background maintenance started (stabilize, fixFingers, checkPredecessor)")
}

// printRing shows this node's ring position and finger table
func (n *Node) printRing() {
	n.mu.RLock()
	defer n.mu.RUnlock()

	fmt.Printf("\n── Ring Position ────────────────────────────────\n")
	fmt.Printf("  This node : ID=%-3d  Addr=%s\n", n.info.ID, n.info.Addr)
	fmt.Printf("  Successor : ID=%-3d  Addr=%s\n", n.fingers[0].ID, n.fingers[0].Addr)
	if n.predecessor != nil {
		fmt.Printf("  Predecessor: ID=%-3d  Addr=%s\n", n.predecessor.ID, n.predecessor.Addr)
	} else {
		fmt.Printf("  Predecessor: (unknown — stabilize not run yet)\n")
	}
	fmt.Printf("\n── Finger Table ─────────────────────────────────\n")
	for i, f := range n.fingers {
		start := n.info.ID + (uint8(1) << uint(i))
		fmt.Printf("  finger[%d]  start=%-3d → ID=%-3d  Addr=%s\n",
			i, start, f.ID, f.Addr)
	}
	fmt.Println()
}
